from selenium import webdriver
import time
path='/home/sanjay/Documents/python/bots/drive/geckodriver-v0.26.0-linux64/geckodriver'
def sel():
	driv=webdriver.Firefox(executable_path=path)
	driv.get("https://colab.research.google.com/drive/1M_UFHvruLNhEBW1x21uSSP8OhfnxsSh5?usp=sharing")
	driv.maximize_window()
	time.sleep(15)	 
	xp="   /html/body/div[6]/div[2]/div[1]/colab-tab-layout-container/div/div/colab-shaded-scroller/div/div/div/div[2]/div[3]/div[2]/div[2]/div[1]/div[2]/div/div[1]/div[2]"
	el=driv.find_element_by_xpath(xp)
	el.send_keys("link")
def cc():
	url= "https://script.google.com/a/macros/saec.ac.in/s/AKfycbxbGNGajrxv-HbX2sVY2OTu7yj9VvxlOMOeQblZFuq7rYm7uyo/exec"
	driv=webdriver.Firefox(executable_path=path)
	driv.get(url)
