import os
from distutils.dir_util import copy_tree
#print(filee)
#print(filee)	
#files={('report.txt',None),('a.txt',None)}
#print(files)
#files=dict(files)
copy_tree("/home/sanjay/Documents/python/bots/drive/report","/home/sanjay/Documents/python/bots/drive")
def auto(ser):
	fi=os.listdir("/home/sanjay/Documents/python/bots/drive/report")
	filee=set()
	for i in fi:
		a=(i,None)
		filee.add(a)
	print(filee)
	for file,mime in filee:
		#tstring="/home/sanjay/Documents/python/bots/drive/report/"+file
		meta={'name':file}
		if mime:
			meta['mimetype']=mime
		res=ser.files().create(body=meta,media_body=file).execute()
		if res:
			print("uploaded")
	for i in fi:
		os.remove(i)
