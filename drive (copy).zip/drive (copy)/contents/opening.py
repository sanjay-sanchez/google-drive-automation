import sys 
from contents import u,tor
def args(ser):
	
	if(sys.argv[1].startswith('-')):
		if(sys.argv[1]=="-h"):
			print('''  ___________ Help module _______

-a -- automated upload on a daily basis
                
   --> this parameter will copy contents in your "copyto" folder
         to your "copiedbyscript" folder in your drive. by default!
             aditionally you may provide two arguments "from" followed by "to" option in args.
                EX: -a  copyfromfolder copytofolder

-d -- download file from your drive
	   --> This parameter will download a file or a digital media given its name
		       Name should be unique. stored in scriptdown folder by default.
			       EX: -d filename savetofolder

-u -- upload to your google drive
	   --> This parameter will upload a file to the "botupload" folder by default                       
              EX: -u filename saveto(saved in root of your drive)

-t -- torrent copy juz give a magnet link
   --> This will copy the content in torrent to your google drive directly without downloading
         LOcally on your computer ! :)
          to torrent folder in root directory.
	        -t magnetlink 

-c -- copy entire folder contents to your google drive 
   --> just click the below link                                            ->thanks to opensource.org <-
         EX: -c

-i -- info about your google drive
   --> get all informatiion about your google drive!
     	-all -- automate the whole script to your needs.
	         -->
		     future update !!
		      hoping for a client !
				''')
		elif(sys.argv[1]=="-a"):
			try:
				u.auto(ser)
			except:
				u.auto(ser)
		elif(sys.argv[1]=='-t'):
			tor.sel()
		elif(sys.argv[1]=='-c'):
			tor.cc()
		elif(sys.argv[1]=='-i'):
			print("future update. WHEN GUI IMPLEMENTED")

		
		else:
			exit()
	else:
		print("invalid syntax")
	#total arguments 
	#n = len(sys.argv) 
	#print("Total arguments passed:", n) 
  
# Arguments passed 
	#print("\nName of Python script:", sys.argv[0]) 
  
	'''print("\nArguments passed:", end = " ") 
	for i in range(1, n):
		print(sys.argv[i], end = " ")''' 
      